import Hike from "./hike.js"

const theHikes = new Hike();

window.addEventListener("load", () => {
    theHikes.displayHikes();
  });